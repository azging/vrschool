import React, { Component } from 'react';
import logo from './logo.svg';
import './home.css';
import Home from './Home.js';

class App extends Component {
    render() {
        return (
            <Home />
        );
    }
}

export default App;
